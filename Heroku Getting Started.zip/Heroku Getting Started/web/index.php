<?php

echo "Admob ====> app-ads.txt";

?>